# QRCodeX - Advanced QR Code Generator

A modern Python library for generating QR codes with support for multiple data types, 
custom styling, and various output formats.

## Features

- Multiple data types support:
  - Text (auto-detects numeric and alphanumeric modes)
  - URLs (auto-detected)
  - Images (PNG, JPEG, etc. converted to data URIs)
  - Binary data (automatically encoded)
- Custom styling:
  - Custom colors (hex, RGB, named colors)
  - Adjustable size and border
  - Error correction levels (L, M, Q, H)
- Multiple output formats:
  - PNG (with transparency support)
  - SVG (scalable vector graphics)
  - PDF (coming soon)
- Modern Python features:
  - Type hints for better IDE support
  - Path handling with pathlib
  - Comprehensive error handling
  - CLI interface (coming soon)

## Installation

### From PyPI

```bash
pip install qrcodex
```

### From Source

```bash
git clone https://github.com/GamingOP69/qrcodex.git
cd qrcodex
pip install -e .
```

### Development Installation

```bash
git clone https://github.com/GamingOP69/qrcodex.git
cd qrcodex
pip install -r requirements.dev.txt
pip install -e .
```

## Usage

### Basic Usage

```python
from qrcodex import QRCodeX

# Create a simple text QR code
qr = QRCodeX()
qr.add_data("Hello, World!")
qr.generate("output.png")

# Create a URL QR code (automatically detected)
qr = QRCodeX()
qr.add_data("https://example.com")  # Automatically detected as URL
qr.generate("url.png")
```

### Advanced Usage

```python
from qrcodex import QRCodeX
from pathlib import Path

# Create a QR code with custom settings
qr = QRCodeX(
    error_correction='H',    # Highest error correction
    box_size=10,            # Pixel size of each module
    border=4,               # Border size
    version=None           # Auto version selection
)

# Add multiple types of data
qr.add_data("https://example.com", data_type='url')
qr.add_data(Path("image.png"), data_type='image')
qr.add_data(bytes([0x00, 0xFF]), data_type='binary')

# Generate with custom colors
qr.generate(
    "output.svg",
    fill_color="#FF0000",    # Red QR code
    back_color="white",      # White background
    format="svg"            # SVG output
)
```

### Error Correction Levels

- L (Low) - 7% of data can be restored
- M (Medium) - 15% of data can be restored
- Q (Quartile) - 25% of data can be restored
- H (High) - 30% of data can be restored

```python
# High error correction for better reliability
qr = QRCodeX(error_correction='H')
qr.add_data("Important data")
qr.generate("reliable.png")
```

### Image QR Codes

```python
from qrcodex import QRCodeX
from pathlib import Path

# Convert image to QR code
qr = QRCodeX(error_correction='M')
qr.add_data(Path("logo.png"), data_type='image')
qr.generate("image_qr.png")

# Use existing data URI
data_uri = "data:image/png;base64,..."
qr.add_data(data_uri, data_type='image')
qr.generate("uri_qr.png")
```

### Binary Data

```python
# Create QR code with binary data
binary_data = bytes([0x00, 0xFF, 0xAA, 0x55])
qr = QRCodeX()
qr.add_data(binary_data, data_type='binary')
qr.generate("binary.png")
```

## Development

### Setup Development Environment

1. Clone the repository:
```bash
git clone https://github.com/GamingOP69/qrcodex.git
cd qrcodex
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate     # Windows
```

3. Install development dependencies:
```bash
pip install -r requirements.dev.txt
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage report
pytest --cov=qrcodex

# Run specific test file
pytest tests/test_generator.py
```

### Code Style

The project uses:
- black for code formatting
- isort for import sorting
- flake8 for linting
- mypy for type checking

Run all checks:
```bash
black .
isort .
flake8 .
mypy src/qrcodex
```

### Building

```bash
# Build distribution packages
python -m build

# Install locally for testing
pip install -e .
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request. For major changes:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Run the tests (`pytest`)
5. Commit your changes (`git commit -m 'Add amazing feature'`)
6. Push to your branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

## Support

If you encounter any issues or have questions:

1. Check the [documentation](https://github.com/GamingOP69/qrcodex/wiki)
2. Open an [issue](https://github.com/GamingOP69/qrcodex/issues)
3. Contact the maintainers